export declare class PaymentModule {
}
