export declare class CheckPaymentDto {
    readonly paymentId: number;
}
