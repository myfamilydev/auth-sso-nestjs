export declare class ShoppingCartModule {
}
