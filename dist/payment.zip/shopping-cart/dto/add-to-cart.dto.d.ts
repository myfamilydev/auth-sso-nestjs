export declare class AddToCartDto {
    readonly username: string;
    userId?: number;
    readonly partId: number;
}
