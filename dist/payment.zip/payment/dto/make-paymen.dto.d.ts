export declare class MakePaymentDto {
    readonly amount: number;
    readonly description?: string;
}
