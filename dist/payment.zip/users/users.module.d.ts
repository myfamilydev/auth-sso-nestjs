export declare class UsersModule {
}
