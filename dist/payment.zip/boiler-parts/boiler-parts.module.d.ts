export declare class BoilerPartsModule {
}
